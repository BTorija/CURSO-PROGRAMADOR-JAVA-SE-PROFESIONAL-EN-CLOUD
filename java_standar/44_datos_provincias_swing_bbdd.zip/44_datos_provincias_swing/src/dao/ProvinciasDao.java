package dao;

import java.util.List;
import java.util.Optional;

import model.Provincia;

public interface ProvinciasDao {

	Optional<Provincia> buscaPorId(String codigo);
	Optional<List<Provincia>> seleccionaTodasLasProvincias();
	Optional<List<Provincia>> buscaProvinciasPorComunidad(String codComunidad);
	
}
