package dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import locator.LocatorConnection;
import model.Comunidad;

class ComunidadesDaoImpl implements ComunidadesDao {

	@Override
	public Optional<Comunidad> buscaPorCodigo(String codigo) {
		try (var c = LocatorConnection.getConnection()) {
			var sql = """
					SELECT * FROM comunidades
					WHERE codigo = ?
					""";
			var ps = c.prepareStatement(sql);
			ps.setString(1, codigo);
			var rs = ps.executeQuery();
			if (rs.next()) {
				return Optional.of(new Comunidad(rs.getString("codigo"), rs.getString("nombre")));
			} else {
				return Optional.empty();
			}
		} catch (Exception e) {
			return Optional.empty();
		}
	}

	@Override
	public Optional<List<Comunidad>> seleccionaTodasLasComunidades() {
		var auxiliar = new ArrayList<Comunidad>();
		try (var c = LocatorConnection.getConnection()) {
			String sql = """
					SELECT * FROM comunidades
					""";
			var s = c.createStatement();
			var rs = s.executeQuery(sql);
			while (rs.next()) {
				auxiliar.add(new Comunidad(rs.getString("codigo"), rs.getString("nombre")));
			}
		} catch (Exception e) {
			return Optional.empty();
		}
		
		if (!auxiliar.isEmpty()) {
			return Optional.of(auxiliar);
		} else {
			return Optional.empty();
		}
	}

}
