package dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import locator.LocatorConnection;
import model.Municipio;

class MunicipiosDaoImpl implements MunicipiosDao {

	@Override
	public Optional<Municipio> buscaPorId(String codigo) {
		try (var c = LocatorConnection.getConnection()) {
			var sql = """
					SELECT * FROM municipios
					WHERE codigo = ?
					""";
			var ps = c.prepareStatement(sql);
			ps.setString(1, codigo);
			var rs = ps.executeQuery();
			if (rs.next()) {
				return Optional.of(new Municipio(rs.getString("codigo"), rs.getString("nombre"), rs.getDouble("superficie"), rs.getInt("poblacion"), rs.getInt("altitud"), rs.getString("codProvincia")));
			} else {
				return Optional.empty();
			}
		} catch (Exception e) {
			return Optional.empty();
		}
	}

	@Override
	public Optional<List<Municipio>> seleccionaTodosLosMunicipios() {
		var auxiliar = new ArrayList<Municipio>();
		try (var c = LocatorConnection.getConnection()) {
			String sql = """
					SELECT * FROM municipios
					""";
			var s = c.createStatement();
			var rs = s.executeQuery(sql);
			while (rs.next()) {
				auxiliar.add(new Municipio(rs.getString("codigo"), rs.getString("nombre"), rs.getDouble("superficie"), rs.getInt("poblacion"), rs.getInt("altitud"), rs.getString("codProvincia")));
			}
		} catch (Exception e) {
			return Optional.empty();
		}
		
		if (!auxiliar.isEmpty()) {
			return Optional.of(auxiliar);
		} else {
			return Optional.empty();
		}
	}

	@Override
	public Optional<List<Municipio>> buscaMunicipiosPorProvincia(String codProvincia) {
		var auxiliar = new ArrayList<Municipio>();
		try (var c = LocatorConnection.getConnection()) {
			String sql = """
					SELECT * FROM municipios
					WHERE codProvincia = ?
					""";
			var ps = c.prepareStatement(sql);
			ps.setString(1, codProvincia);
			var rs = ps.executeQuery();
			while (rs.next()) {
				auxiliar.add(new Municipio(rs.getString("codigo"), rs.getString("nombre"), rs.getDouble("superficie"), rs.getInt("poblacion"), rs.getInt("altitud"), rs.getString("codProvincia")));
			}
		} catch (Exception e) {
			return Optional.empty();
		}
		
		if (!auxiliar.isEmpty()) {
			return Optional.of(auxiliar);
		} else {
			return Optional.empty();
		}
	}

}
