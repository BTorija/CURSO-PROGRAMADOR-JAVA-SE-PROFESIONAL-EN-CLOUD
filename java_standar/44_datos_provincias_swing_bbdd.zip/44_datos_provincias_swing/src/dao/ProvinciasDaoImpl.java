package dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import locator.LocatorConnection;
import model.Provincia;

class ProvinciasDaoImpl implements ProvinciasDao {

	@Override
	public Optional<Provincia> buscaPorId(String codigo) {
		try (var c = LocatorConnection.getConnection()) {
			var sql = """
					SELECT * FROM provincias
					WHERE codigo = ?
					""";
			var ps = c.prepareStatement(sql);
			ps.setString(1, codigo);
			var rs = ps.executeQuery();
			if (rs.next()) {
				return Optional.of(new Provincia(rs.getString("codigo"), rs.getString("nombre"), rs.getString("codComunidad")));
			} else {
				return Optional.empty();
			}
		} catch (Exception e) {
			return Optional.empty();
		}
	}

	@Override
	public Optional<List<Provincia>> seleccionaTodasLasProvincias() {
		var auxiliar = new ArrayList<Provincia>();
		try (var c = LocatorConnection.getConnection()) {
			String sql = """
					SELECT * FROM provincias
					""";
			var s = c.createStatement();
			var rs = s.executeQuery(sql);
			while (rs.next()) {
				auxiliar.add(new Provincia(rs.getString("codigo"), rs.getString("nombre"), rs.getString("codComunidad")));
			}
		} catch (Exception e) {
			return Optional.empty();
		}
		
		if (!auxiliar.isEmpty()) {
			return Optional.of(auxiliar);
		} else {
			return Optional.empty();
		}
	}

	@Override
	public Optional<List<Provincia>> buscaProvinciasPorComunidad(String codComunidad) {
		var auxiliar = new ArrayList<Provincia>();
		try (var c = LocatorConnection.getConnection()) {
			String sql = """
					SELECT * FROM provincias
					WHERE codComunidad = ?
					""";
			var s = c.prepareStatement(sql);
			s.setString(1, codComunidad);
			var rs = s.executeQuery();
			while (rs.next()) {
				auxiliar.add(new Provincia(rs.getString("codigo"), rs.getString("nombre"), rs.getString("codComunidad")));
			}
		} catch (Exception e) {
			return Optional.empty();
		}
		
		if (!auxiliar.isEmpty()) {
			return Optional.of(auxiliar);
		} else {
			return Optional.empty();
		}
	}

}
