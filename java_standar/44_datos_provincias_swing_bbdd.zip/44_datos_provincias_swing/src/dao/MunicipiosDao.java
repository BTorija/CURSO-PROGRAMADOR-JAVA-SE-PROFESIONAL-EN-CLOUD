package dao;

import java.util.List;
import java.util.Optional;

import model.Municipio;

public interface MunicipiosDao {

	Optional<Municipio> buscaPorId(String codigo);
	Optional<List<Municipio>> seleccionaTodosLosMunicipios();
	Optional<List<Municipio>> buscaMunicipiosPorProvincia(String codProvincia);
	
}
