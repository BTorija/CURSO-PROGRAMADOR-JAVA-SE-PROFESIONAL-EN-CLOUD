package dao;

import java.util.List;
import java.util.Optional;

import model.Comunidad;

public interface ComunidadesDao {
	
	Optional<Comunidad> buscaPorCodigo(String codigo);
	Optional<List<Comunidad>> seleccionaTodasLasComunidades();
	
}
