package adaptadores;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.swing.DefaultComboBoxModel;

import dao.ComunidadesDaoFactory;
import model.Provincia;

public class ComboBoxModelProvinciasImpl extends DefaultComboBoxModel<Provincia> {

	private static final long serialVersionUID = 1L;

	List<Provincia> provincias;
	
	public ComboBoxModelProvinciasImpl(String codComunidad) {
		Optional<List<Provincia>> op = ComunidadesDaoFactory.getProvinciasDao().buscaProvinciasPorComunidad(codComunidad);
		
		if (op.isPresent()) {
			this.provincias = op.get();
		} else {
			this.provincias = new ArrayList<Provincia>();
		}
	}

	@Override
	public int getSize() {
		return provincias.size();
	}

	@Override
	public Provincia getElementAt(int index) {
		if (provincias.isEmpty()) {
			return null;
		}
		
		return provincias.get(index);
	}
	
	
	
}
