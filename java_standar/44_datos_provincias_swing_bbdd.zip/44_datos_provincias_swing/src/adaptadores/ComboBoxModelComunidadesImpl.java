package adaptadores;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.swing.DefaultComboBoxModel;

import dao.ComunidadesDaoFactory;
import model.Comunidad;

public class ComboBoxModelComunidadesImpl extends DefaultComboBoxModel<Comunidad> {

	private static final long serialVersionUID = 1L;

	List<Comunidad> comunidades;
	
	public ComboBoxModelComunidadesImpl() {
		Optional<List<Comunidad>> oc = ComunidadesDaoFactory.getComunidadesDao().seleccionaTodasLasComunidades();
		
		if (oc.isPresent()) {
			this.comunidades = oc.get();
		} else {
			this.comunidades = new ArrayList<Comunidad>();
		}
	}

	@Override
	public int getSize() {
		return comunidades.size();
	}

	@Override
	public Comunidad getElementAt(int index) {
		if (comunidades.isEmpty()) {
			return null;
		}
		
		return comunidades.get(index);
	}
	
	
	
}
