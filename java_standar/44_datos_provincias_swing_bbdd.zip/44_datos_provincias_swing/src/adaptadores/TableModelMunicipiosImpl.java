package adaptadores;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.swing.table.AbstractTableModel;

import dao.ComunidadesDaoFactory;
import model.Municipio;

public class TableModelMunicipiosImpl extends AbstractTableModel { // Tenemos que usar esta clase no la DefaultTableModel
																// porque no funciona, da fallos

	private static final long serialVersionUID = 1L;

	List<Municipio> municipios;

	public TableModelMunicipiosImpl(String codProvincia) {
		Optional<List<Municipio>> om = ComunidadesDaoFactory.getMunicipiosDao().buscaMunicipiosPorProvincia(codProvincia);

		if (om.isPresent()) {
			this.municipios = om.get();
		} else {
			this.municipios = new ArrayList<Municipio>();
		}
	}

	@Override
	public int getRowCount() {
		return municipios.size();
	}

	@Override
	public int getColumnCount() {
		return 4;
	}

	@Override
	public String getColumnName(int column) {
		return switch (column) {
		case 0 -> "Nombre";
		case 1 -> "Población";
		case 2 -> "Altitud";
		case 3 -> "Superficie";
		default -> "";
		};
	}

	@Override
	public Object getValueAt(int row, int column) {
		return switch (column) {
		case 0 -> municipios.get(row).getNombre();
		case 1 -> municipios.get(row).getPoblacion();
		case 2 -> municipios.get(row).getAltitud();
		case 3 -> municipios.get(row).getSuperficie();
		default -> "";
		};
	}

	@Override
	public Class<?> getColumnClass(int columnIndex) {
		return switch (columnIndex) {
		case 0 -> String.class;
		case 1 -> Integer.class;
		case 2 -> Integer.class;
		case 3 -> Double.class;
		default -> String.class;
		};
	}

}
