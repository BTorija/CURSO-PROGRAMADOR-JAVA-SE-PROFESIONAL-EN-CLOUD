package service;

import java.util.List;
import java.util.Optional;

import dao.ComunidadesDao;
import dao.ComunidadesDaoFactory;
import dao.MunicipiosDao;
import dao.ProvinciasDao;
import model.Comunidad;
import model.Municipio;
import model.Provincia;

class ComunidadesServiceImpl implements ComunidadesService {

	private ComunidadesDao cd;
	private ProvinciasDao pd;
	private MunicipiosDao md;
	
	public ComunidadesServiceImpl() {
		this.cd = ComunidadesDaoFactory.getComunidadesDao();
		this.pd = ComunidadesDaoFactory.getProvinciasDao();
		this.md = ComunidadesDaoFactory.getMunicipiosDao();
	}
	
	@Override
	public Optional<List<Comunidad>> getComunidades() {
		Optional<List<Comunidad>> oc =  cd.seleccionaTodasLasComunidades();
		return oc.isPresent() ? oc : Optional.empty();
	}

	@Override
	public Optional<List<Provincia>> getProvinciasDeUnaComunidad(String codComunidad) {
		Optional<List<Provincia>> op = pd.buscaProvinciasPorComunidad(codComunidad);
		return op.isPresent() ? op : Optional.empty();
	}

	@Override
	public Optional<List<Municipio>> getMunicipiosDeUnaProvincia(String codProvincia) {
		Optional<List<Municipio>> om = md.buscaMunicipiosPorProvincia(codProvincia);
		return om.isPresent() ? om : Optional.empty();
	}

}
