package service;

import java.util.List;
import java.util.Optional;

import model.Comunidad;
import model.Municipio;
import model.Provincia;

public interface ComunidadesService {
	
	Optional<List<Comunidad>> getComunidades();
	Optional<List<Provincia>> getProvinciasDeUnaComunidad(String codComunidad);
	Optional<List<Municipio>> getMunicipiosDeUnaProvincia(String codProvincia);
	
}
