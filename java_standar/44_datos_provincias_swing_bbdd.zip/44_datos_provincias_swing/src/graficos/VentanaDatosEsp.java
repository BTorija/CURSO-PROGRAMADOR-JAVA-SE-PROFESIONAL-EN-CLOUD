package graficos;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import adaptadores.ComboBoxModelComunidadesImpl;
import adaptadores.ComboBoxModelProvinciasImpl;
import adaptadores.TableModelMunicipiosImpl;
import model.Comunidad;
import model.Provincia;
import javax.swing.SwingConstants;

public class VentanaDatosEsp extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaDatosEsp frame = new VentanaDatosEsp();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaDatosEsp() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 507, 481);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel jLabelProvincias = new JLabel("Provincia");
		jLabelProvincias.setHorizontalAlignment(SwingConstants.CENTER);
		jLabelProvincias.setFont(new Font("Tahoma", Font.BOLD, 12));
		jLabelProvincias.setBounds(114, 72, 219, 24);
		contentPane.add(jLabelProvincias);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 157, 471, 274);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JComboBox<Provincia> JComboBoxProvincias = new JComboBox<Provincia>();
		JComboBoxProvincias.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					Provincia provinciaSeleccionada = (Provincia) JComboBoxProvincias.getSelectedItem();
					TableModelMunicipiosImpl model = new TableModelMunicipiosImpl(provinciaSeleccionada.getCodigo());
		            table.setModel(model);
		            table.setRowSorter(new TableRowSorter<TableModel>(model));
				}
			}
		});
		JComboBoxProvincias.setBounds(114, 97, 219, 24);
		contentPane.add(JComboBoxProvincias);

		JLabel jLabelComunidades = new JLabel("Comunidad");
		jLabelComunidades.setHorizontalAlignment(SwingConstants.CENTER);
		jLabelComunidades.setFont(new Font("Tahoma", Font.BOLD, 12));
		jLabelComunidades.setBounds(114, 11, 219, 24);
		contentPane.add(jLabelComunidades);

		JComboBox<Comunidad> JComboBoxComunidades = new JComboBox<Comunidad>();
		JComboBoxComunidades.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					Comunidad comunidadSeleccionada = (Comunidad) JComboBoxComunidades.getSelectedItem();
					JComboBoxProvincias.setModel(new ComboBoxModelProvinciasImpl(comunidadSeleccionada.getCodigo()));
					table.setModel(new DefaultTableModel());
				}
			}
		});
		JComboBoxComunidades.setBounds(114, 35, 219, 24);
		contentPane.add(JComboBoxComunidades);
		JComboBoxComunidades.setModel(new ComboBoxModelComunidadesImpl());

		JLabel jLabelFechaHora = new JLabel("");
		jLabelFechaHora.setFont(new Font("Tahoma", Font.BOLD, 12));
		jLabelFechaHora.setBounds(344, 0, 147, 24);

		contentPane.add(jLabelFechaHora);

		creaHiloParaMostrarLaFechaHora(jLabelFechaHora);
		
		JLabel JLabelMunicipios = new JLabel("Municipios");
		JLabelMunicipios.setHorizontalAlignment(SwingConstants.CENTER);
		JLabelMunicipios.setFont(new Font("Tahoma", Font.BOLD, 12));
		JLabelMunicipios.setBounds(115, 132, 218, 24);
		contentPane.add(JLabelMunicipios);
	}

	private void creaHiloParaMostrarLaFechaHora(JLabel jLabelFechaHora) {
		ExecutorService es = Executors.newCachedThreadPool();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyy HH:mm:ss");
		es.submit(() -> {
			while (true) {
				jLabelFechaHora.setText(dtf.format(LocalDateTime.now()));
			}
		});
		
	}
}
