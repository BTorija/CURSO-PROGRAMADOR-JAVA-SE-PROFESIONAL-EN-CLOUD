package model;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class Municipio {

	private String codigo;
	private String nombre;
	private double superficie;
	private int poblacion;
	private int altitud;
	private String codProvincia;
	
	@Override
	public String toString() {
		return nombre;
	}
}
